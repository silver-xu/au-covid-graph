it('1 should equal to 1', () => {
  expect(1).toEqual(1);
});
